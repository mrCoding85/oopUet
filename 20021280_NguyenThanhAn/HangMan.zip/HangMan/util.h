#include<bits/stdc++.h>
using namespace std;

bool isAllDash(const string &s);
bool isAllNotDash(const	string &s);
bool isSuitableWord(const string &word, const string &secretWord,const set<char> &remainingChars);
