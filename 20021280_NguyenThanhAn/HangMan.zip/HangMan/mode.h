
#include <ctime>
#include <cctype>
#include<bits/stdc++.h>
#include "draw.h"
#include "word.h"
using namespace std;

void standardMode();
void botGuessingMode();
void updateHighScore_OfClassic(const string &level,const string &namePlayer,const double &score,const double &time);
void keep_playing(string &play);
